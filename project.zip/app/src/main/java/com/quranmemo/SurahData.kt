package com.quranmemo

// Name to number of verses, in order of surah 1..114
val SURAHS: List<Pair<String, Int>> = listOf(
    "Al-Fatihah" to 7, "Al-Baqarah" to 286, "Ali 'Imran" to 200, "An-Nisa" to 176,
    "Al-Ma'idah" to 120, "Al-An'am" to 165, "Al-A'raf" to 206, "Al-Anfal" to 75,
    "At-Tawbah" to 129, "Yunus" to 109, "Hud" to 123, "Yusuf" to 111,
    "Ar-Ra'd" to 43, "Ibrahim" to 52, "Al-Hijr" to 99, "An-Nahl" to 128,
    "Al-Isra" to 111, "Al-Kahf" to 110, "Maryam" to 98, "Ta-Ha" to 135,
    "Al-Anbiya" to 112, "Al-Hajj" to 78, "Al-Mu'minun" to 118, "An-Nur" to 64,
    "Al-Furqan" to 77, "Ash-Shu'ara" to 227, "An-Naml" to 93, "Al-Qasas" to 88,
    "Al-'Ankabut" to 69, "Ar-Rum" to 60, "Luqman" to 34, "As-Sajdah" to 30,
    "Al-Ahzab" to 73, "Saba" to 54, "Fatir" to 45, "Ya-Sin" to 83,
    "As-Saffat" to 182, "Sad" to 88, "Az-Zumar" to 75, "Ghafir" to 85,
    "Fussilat" to 54, "Ash-Shura" to 53, "Az-Zukhruf" to 89, "Ad-Dukhan" to 59,
    "Al-Jathiyah" to 37, "Al-Ahqaf" to 35, "Muhammad" to 38, "Al-Fath" to 29,
    "Al-Hujurat" to 18, "Qaf" to 45, "Adh-Dhariyat" to 60, "At-Tur" to 49,
    "An-Najm" to 62, "Al-Qamar" to 55, "Ar-Rahman" to 78, "Al-Waqi'ah" to 96,
    "Al-Hadid" to 29, "Al-Mujadila" to 22, "Al-Hashr" to 24, "Al-Mumtahanah" to 13,
    "As-Saff" to 14, "Al-Jumu'ah" to 11, "Al-Munafiqun" to 11, "At-Taghabun" to 18,
    "At-Talaq" to 12, "At-Tahrim" to 12, "Al-Mulk" to 30, "Al-Qalam" to 52,
    "Al-Haqqah" to 52, "Al-Ma'arij" to 44, "Nuh" to 28, "Al-Jinn" to 28,
    "Al-Muzzammil" to 20, "Al-Muddaththir" to 56, "Al-Qiyamah" to 40, "Al-Insan" to 31,
    "Al-Mursalat" to 50, "An-Naba" to 40, "An-Nazi'at" to 46, "'Abasa" to 42,
    "At-Takwir" to 29, "Al-Infitar" to 19, "Al-Mutaffifin" to 36, "Al-Inshiqaq" to 25,
    "Al-Buruj" to 22, "At-Tariq" to 17, "Al-A'la" to 19, "Al-Ghashiyah" to 26,
    "Al-Fajr" to 30, "Al-Balad" to 20, "Ash-Shams" to 15, "Al-Layl" to 21,
    "Ad-Duha" to 11, "Ash-Sharh" to 8, "At-Tin" to 8, "Al-'Alaq" to 19,
    "Al-Qadr" to 5, "Al-Bayyinah" to 8, "Az-Zalzalah" to 8, "Al-'Adiyat" to 11,
    "Al-Qari'ah" to 11, "At-Takathur" to 8, "Al-'Asr" to 3, "Al-Humazah" to 9,
    "Al-Fil" to 5, "Quraysh" to 4, "Al-Ma'un" to 7, "Al-Kawthar" to 3,
    "Al-Kafirun" to 6, "An-Nasr" to 3, "Al-Masad" to 5, "Al-Ikhlas" to 4,
    "Al-Falaq" to 5, "An-Nas" to 6
)
