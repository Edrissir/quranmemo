package com.quranmemo

import android.media.MediaPlayer
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.resume

// If downloads fail with "not found", change this folder name (see everyayah.com/data)
const val RECITER_FOLDER = "Saood_ash-Shuraym_128kbps"

private var current: MediaPlayer? = null
@Volatile private var pausedFlag = false

fun fileName(s: Int, v: Int) = "%03d%03d.mp3".format(s, v)

suspend fun downloadVerse(dir: File, s: Int, v: Int): Boolean = withContext(Dispatchers.IO) {
    val f = File(dir, fileName(s, v))
    if (f.exists()) return@withContext true
    val tmp = File(dir, fileName(s, v) + ".tmp")
    try {
        val url = URL("https://everyayah.com/data/$RECITER_FOLDER/${fileName(s, v)}")
        val c = url.openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        if (c.responseCode != 200) {
            c.disconnect()
            return@withContext false
        }
        c.inputStream.use { input -> tmp.outputStream().use { out -> input.copyTo(out) } }
        c.disconnect()
        tmp.renameTo(f)
    } catch (e: Exception) {
        tmp.delete()
        false
    }
}

suspend fun playFile(f: File) = suspendCancellableCoroutine<Unit> { cont ->
    val p = MediaPlayer()
    current = p
    cont.invokeOnCancellation {
        try { p.release() } catch (_: Exception) {}
        if (current === p) current = null
    }
    try {
        p.setDataSource(f.absolutePath)
        p.setOnCompletionListener {
            try { p.release() } catch (_: Exception) {}
            if (current === p) current = null
            if (cont.isActive) cont.resume(Unit)
        }
        p.setOnErrorListener { _, _, _ ->
            try { p.release() } catch (_: Exception) {}
            if (current === p) current = null
            if (cont.isActive) cont.resume(Unit)
            true
        }
        p.prepare()
        if (!pausedFlag) p.start()
    } catch (e: Exception) {
        try { p.release() } catch (_: Exception) {}
        if (current === p) current = null
        if (cont.isActive) cont.resume(Unit)
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dir = File(filesDir, "audio")
        dir.mkdirs()
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize().statusBarsPadding()) { App(dir) }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { current?.release() } catch (_: Exception) {}
        current = null
    }
}

@Composable
fun App(dir: File) {
    val scope = rememberCoroutineScope()
    var selected by remember { mutableIntStateOf(0) }
    var tick by remember { mutableIntStateOf(0) }
    var playing by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("") }
    var loop by remember { mutableStateOf(false) }
    var rep by remember { mutableIntStateOf(1) }
    var paused by remember { mutableStateOf(false) }
    var playJob by remember { mutableStateOf<Job?>(null) }
    var dlJob by remember { mutableStateOf<Job?>(null) }

    fun stopPlay() {
        playJob?.cancel()
        playJob = null
        try { current?.release() } catch (_: Exception) {}
        current = null
        playing = 0
        pausedFlag = false
        paused = false
    }

    fun togglePause() {
        if (paused) {
            pausedFlag = false
            paused = false
            try { current?.start() } catch (_: Exception) {}
        } else {
            pausedFlag = true
            paused = true
            try { current?.pause() } catch (_: Exception) {}
        }
    }

    fun startPlay(s: Int, from: Int, to: Int) {
        stopPlay()
        playJob = scope.launch {
            do {
                var any = false
                for (v in from..to) {
                    val f = File(dir, fileName(s, v))
                    if (!f.exists()) continue
                    any = true
                    playing = v
                    for (i in 1..rep) playFile(f)
                }
                if (!any) status = "No downloaded verses in this range"
            } while (loop && any)
            // reached only when playback finishes normally (cancel skips this)
            playing = 0
            pausedFlag = false
            paused = false
            playJob = null
        }
    }

    fun downloadRange(s: Int, from: Int, to: Int) {
        dlJob?.cancel()
        dlJob = scope.launch {
            var failed = 0
            for (v in from..to) {
                status = "Downloading verse $v of ${SURAHS[s - 1].second}..."
                if (!downloadVerse(dir, s, v)) failed++
                tick++
            }
            status = if (failed == 0) "Download complete"
            else "$failed verse(s) failed. Check internet and tap again"
            dlJob = null
        }
    }

    BackHandler(enabled = selected != 0) {
        stopPlay()
        dlJob?.cancel()
        dlJob = null
        status = ""
        selected = 0
    }

    if (selected == 0) {
        val names = remember(tick, selected) { (dir.list() ?: emptyArray()).toSet() }
        Column(Modifier.fillMaxSize()) {
            Text(
                "Quran Memo",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(16.dp)
            )
            LazyColumn(Modifier.fillMaxSize()) {
                items((1..114).toList()) { n ->
                    val (name, count) = SURAHS[n - 1]
                    val have = (1..count).count { names.contains(fileName(n, it)) }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { selected = n }
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("$n. $name", fontSize = 18.sp)
                            Text("$count verses", fontSize = 13.sp)
                        }
                        Text(
                            "$have/$count saved",
                            fontSize = 13.sp,
                            color = if (have == count) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.outline
                        )
                    }
                    HorizontalDivider()
                }
            }
        }
    } else {
        val s = selected
        val (name, count) = SURAHS[s - 1]
        val t = tick
        Column(Modifier.fillMaxSize()) {
            Column(Modifier.padding(12.dp)) {
                Text("$s. $name  ($count verses)", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(onClick = { downloadRange(s, 1, count) }) {
                        Text("Download all")
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (playJob == null) {
                        Button(onClick = { startPlay(s, 1, count) }) { Text("Play all") }
                    } else {
                        Button(onClick = { togglePause() }) {
                            Text(if (paused) "Resume" else "Pause")
                        }
                        FilledTonalButton(onClick = { stopPlay() }) { Text("Stop") }
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Repeat surah")
                    Switch(
                        checked = loop,
                        onCheckedChange = { loop = it },
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Each verse:")
                    for (r in listOf(1, 3, 5, 10)) {
                        TextButton(onClick = { rep = r }) {
                            Text(
                                "${r}x",
                                fontWeight = if (rep == r) FontWeight.Bold else FontWeight.Normal,
                                color = if (rep == r) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.outline
                            )
                        }
                    }
                }
                if (status.isNotEmpty()) Text(status, fontSize = 13.sp)
            }
            HorizontalDivider()
            LazyColumn(Modifier.fillMaxSize()) {
                items((1..count).toList()) { v ->
                    val saved = t >= 0 && File(dir, fileName(s, v)).exists()
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Verse $v",
                            fontSize = 17.sp,
                            fontWeight = if (playing == v) FontWeight.Bold else FontWeight.Normal,
                            color = if (playing == v) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurface
                        )
                        Row {
                            if (!saved) {
                                TextButton(onClick = { downloadRange(s, v, v) }) { Text("Download") }
                            } else {
                                TextButton(onClick = { startPlay(s, v, v) }) { Text("Play") }
                                TextButton(onClick = { startPlay(s, v, count) }) { Text("From here") }
                            }
                        }
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}
